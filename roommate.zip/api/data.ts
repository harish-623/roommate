import type { VercelRequest, VercelResponse } from '@vercel/node';
import { list, put, get } from '@vercel/blob';
import ExcelJS from 'exceljs';
import { createClient } from '@supabase/supabase-js';

const FILE = 'roommate/roommate-expenses.xlsx';
const token = process.env.BLOB_READ_WRITE_TOKEN;
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnon = process.env.SUPABASE_ANON_KEY;

function send(res: VercelResponse, status: number, body: unknown) { return res.status(status).json(body); }
async function requireUser(req: VercelRequest) {
  const header = req.headers.authorization || '';
  const jwt = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!jwt || !supabaseUrl || !supabaseAnon) return null;
  const supabase = createClient(supabaseUrl, supabaseAnon, { auth: { persistSession: false } });
  const { data, error } = await supabase.auth.getUser(jwt);
  return error ? null : data.user;
}
function blank() { return { roommates: [
  { id: 'r1', name: 'Roommate 1', email: '' }, { id: 'r2', name: 'Roommate 2', email: '' },
  { id: 'r3', name: 'Roommate 3', email: '' }, { id: 'r4', name: 'Roommate 4', email: '' }
], expenses: [], payments: [], revision: 0, updatedAt: new Date().toISOString() }; }

async function readWorkbook(): Promise<any> {
  if (!token) throw new Error('Missing BLOB_READ_WRITE_TOKEN');
  const found = await list({ prefix: FILE, token });
  const blob = found.blobs.find(b => b.pathname === FILE);
  if (!blob) return blank();
  const result = await get(blob.url, { access: 'private', token });
  if (!result || result.statusCode !== 200 || !result.stream) return blank();
  const chunks: Uint8Array[] = [];
  const reader = result.stream.getReader();
  while (true) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); }
  const size = chunks.reduce((n, c) => n + c.length, 0);
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(bytes as any);
  const readSheet = (name: string) => {
    const sheet = workbook.getWorksheet(name); if (!sheet) return [];
    const headers = (sheet.getRow(1).values as any[]).slice(1);
    const rows: any[] = [];
    sheet.eachRow((row, n) => { if (n === 1) return; const item: any = {}; headers.forEach((h: string, i: number) => item[h] = row.getCell(i + 1).value); if (Object.keys(item).length) rows.push(item); });
    return rows;
  };
  const meta = readSheet('Meta')[0] || {};
  return { roommates: readSheet('Roommates'), expenses: readSheet('Expenses'), payments: readSheet('Payments'), revision: Number(meta.revision || 0), updatedAt: String(meta.updatedAt || new Date().toISOString()) };
}
async function writeWorkbook(data: any) {
  const workbook = new ExcelJS.Workbook(); workbook.creator = 'RoomMate'; workbook.created = new Date();
  const add = (name: string, headers: string[], rows: any[]) => {
    const sheet = workbook.addWorksheet(name); sheet.addRow(headers);
    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } }; sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF635BFF' } };
    for (const row of rows) sheet.addRow(headers.map(h => row[h] ?? ''));
    sheet.columns.forEach(col => col.width = 20); sheet.views = [{ state: 'frozen', ySplit: 1 }];
  };
  add('Roommates', ['id','name','email'], data.roommates || []);
  add('Expenses', ['id','date','month','category','description','amount','paidBy','createdAt'], data.expenses || []);
  add('Payments', ['id','month','roommateId','amount','paid','paidAt'], data.payments || []);
  add('Meta', ['revision','updatedAt'], [{ revision: data.revision, updatedAt: data.updatedAt }]);
  const buffer = await workbook.xlsx.writeBuffer();
  await put(FILE, Buffer.from(buffer), { access: 'private', token: token!, contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', addRandomSuffix: false, allowOverwrite: true });
}
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (!['GET','PUT'].includes(req.method || '')) return send(res, 405, { error: 'Method not allowed' });
  if (!token || !supabaseUrl || !supabaseAnon) return send(res, 500, { error: 'Server environment variables are not configured.' });
  const user = await requireUser(req); if (!user) return send(res, 401, { error: 'Please sign in again.' });
  try {
    const current = await readWorkbook();
    if (req.method === 'GET') return send(res, 200, current);
    const incoming = req.body;
    if (!incoming || !Array.isArray(incoming.roommates) || !Array.isArray(incoming.expenses) || !Array.isArray(incoming.payments)) return send(res, 400, { error: 'Invalid workbook data.' });
    if (Number(incoming.revision) !== Number(current.revision)) return send(res, 409, { error: 'This workbook changed in another session. Refresh and try again.', currentRevision: current.revision });
    const next = { roommates: incoming.roommates.slice(0, 4), expenses: incoming.expenses, payments: incoming.payments, revision: current.revision + 1, updatedAt: new Date().toISOString() };
    await writeWorkbook(next); return send(res, 200, next);
  } catch (e: any) { console.error(e); return send(res, 500, { error: e?.message || 'Unable to access the Excel workbook.' }); }
}
