import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { RootComponent } from './app/root.component';
import { routes } from './app/app.routes';
import { authInterceptor } from './app/auth.interceptor';
bootstrapApplication(RootComponent, { providers: [provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor]))] }).catch(err => console.error(err));
