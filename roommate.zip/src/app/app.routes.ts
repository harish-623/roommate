import { inject } from '@angular/core';
import { CanActivateFn, Router, Routes } from '@angular/router';
import { SupabaseService } from './supabase.service';

const authenticatedGuard: CanActivateFn = async () => {
  const auth = inject(SupabaseService);
  const router = inject(Router);
  return await auth.user() ? true : router.createUrlTree(['/login']);
};

const guestGuard: CanActivateFn = async () => {
  const auth = inject(SupabaseService);
  const router = inject(Router);
  return await auth.user() ? router.createUrlTree(['/home']) : true;
};

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  { path: 'login', loadComponent: () => import('./login.component').then(module => module.LoginComponent), canActivate: [guestGuard] },
  { path: 'register', loadComponent: () => import('./register.component').then(module => module.RegisterComponent), canActivate: [guestGuard] },
  { path: 'home', loadComponent: () => import('./app.component').then(module => module.HomeComponent), canActivate: [authenticatedGuard] },
  { path: '**', redirectTo: 'home' }
];
