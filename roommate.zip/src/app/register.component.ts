import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { SupabaseService } from './supabase.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <main class="auth-shell">
      <section class="auth-art">
        <div class="brand"><span class="brand-icon">⌂</span> RoomMate</div>
        <div class="art-copy">
          <span class="eyebrow">SHARED LIVING, SIMPLIFIED</span>
          <h1>Good roommates.<br><em>Clear accounts.</em></h1>
          <p>One simple place to manage rent, groceries and every shared expense.</p>
          <div class="mini-card"><div class="mini-avatars"><b>R</b><b>A</b><b>K</b><b>S</b></div><span>Everything split fairly, every month.</span></div>
        </div>
        <div class="art-footer">Made for the people you share a home with.</div>
      </section>
      <section class="auth-panel">
        <div class="auth-form">
          <span class="eyebrow purple">WELCOME HOME</span>
          <h2>Create your account</h2>
          <p class="muted">Join your household workspace.</p>
          <form (ngSubmit)="register()">
            <label for="register-email">Email address</label>
            <input id="register-email" type="email" name="email" [(ngModel)]="email" placeholder="you@example.com" required autocomplete="email">
            <label for="register-password">Password</label>
            <input id="register-password" type="password" name="password" [(ngModel)]="password" placeholder="At least 6 characters" required minlength="6" autocomplete="new-password">
            <button class="primary full" type="submit" [disabled]="busy">{{busy ? 'Please wait…' : 'Create account'}} <span>→</span></button>
          </form>
          <p class="switch">Already have an account? <a routerLink="/login">Sign in</a></p>
          <p class="hint">Your household data is available only after signing in.</p>
          @if (error) { <div class="error" role="alert">{{error}}</div> }
          @if (success) { <div class="hint" role="status">{{success}}</div> }
        </div>
      </section>
    </main>
  `
})
export class RegisterComponent {
  private auth = inject(SupabaseService);
  private router = inject(Router);
  email = '';
  password = '';
  busy = false;
  error = this.auth.isConfigured
    ? ''
    : 'Configure your Supabase project URL and anon key in src/environments/environment.ts before registering.';
  success = '';

  async register() {
    if (!this.auth.isConfigured) {
      this.error = 'Configure your Supabase project URL and anon key in src/environments/environment.ts before registering.';
      return;
    }

    this.busy = true;
    this.error = '';
    this.success = '';
    try {
      const { data, error } = await this.auth.signUp(this.email.trim(), this.password);
      if (error) throw error;
      if (data.session) {
        await this.router.navigate(['/home']);
      } else {
        this.success = 'Account created. Check your email to confirm your account, then sign in.';
      }
    } catch (error) {
      this.error = error instanceof Error ? error.message : 'Unable to create your account.';
    } finally {
      this.busy = false;
    }
  }
}
