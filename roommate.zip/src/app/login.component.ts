import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { SupabaseService } from './supabase.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <main class="auth-shell">
      <section class="auth-art">
        <div class="brand"><span class="brand-icon">⌂</span> RoomMate</div>
        <div class="art-copy">
          <span class="eyebrow">SHARED LIVING, SIMPLIFIED</span>
          <h1>Good roommates.<br><em>Clear accounts.</em></h1>
          <p>One simple place to manage rent, groceries and every shared expense.</p>
          <div class="mini-card"><div class="mini-avatars"><b>R</b><b>A</b><b>K</b><b>S</b></div><span>Everything split fairly, every month.</span></div>
        </div>
        <div class="art-footer">Made for the people you share a home with.</div>
      </section>
      <section class="auth-panel">
        <div class="auth-form">
          <span class="eyebrow purple">WELCOME HOME</span>
          <h2>Welcome back</h2>
          <p class="muted">Sign in to manage your household expenses.</p>
          <form (ngSubmit)="login()">
            <label for="login-email">Email address</label>
            <input id="login-email" type="email" name="email" [(ngModel)]="email" placeholder="you@example.com" required autocomplete="email">
            <label for="login-password">Password</label>
            <input id="login-password" type="password" name="password" [(ngModel)]="password" placeholder="Your password" required autocomplete="current-password">
            <button class="primary full" type="submit" [disabled]="busy">{{busy ? 'Please wait…' : 'Sign in'}} <span>→</span></button>
          </form>
          <p class="switch">New to RoomMate? <a routerLink="/register">Create account</a></p>
          <p class="hint">Your household data is available only after signing in.</p>
          @if (error) { <div class="error" role="alert">{{error}}</div> }
        </div>
      </section>
    </main>
  `
})
export class LoginComponent {
  private auth = inject(SupabaseService);
  private router = inject(Router);
  email = '';
  password = '';
  busy = false;
  error = this.auth.isConfigured
    ? ''
    : 'Configure your Supabase project URL and anon key in src/environments/environment.ts before signing in.';

  async login() {
    if (!this.auth.isConfigured) {
      this.error = 'Configure your Supabase project URL and anon key in src/environments/environment.ts before signing in.';
      return;
    }

    this.busy = true;
    this.error = '';
    try {
      const { data, error } = await this.auth.signIn(this.email.trim(), this.password);
      if (error) throw error;
      if (!data.user) throw new Error('Sign-in did not return a user. Please try again.');
      await this.router.navigate(['/home']);
    } catch (error) {
      this.error = error instanceof Error ? error.message : 'Unable to sign in.';
    } finally {
      this.busy = false;
    }
  }
}
