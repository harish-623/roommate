import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { WorkbookData, Expense, Roommate } from './models';
@Injectable({ providedIn: 'root' })
export class DataService {
  private http = inject(HttpClient);
  async load(): Promise<WorkbookData> { return firstValueFrom(this.http.get<WorkbookData>('/api/data')); }
  async save(data: WorkbookData): Promise<WorkbookData> { return firstValueFrom(this.http.put<WorkbookData>('/api/data', data)); }
  async addExpense(expense: Expense, data: WorkbookData): Promise<WorkbookData> { return this.save({ ...data, expenses: [expense, ...data.expenses] }); }
  async updateRoommates(roommates: Roommate[], data: WorkbookData): Promise<WorkbookData> { return this.save({ ...data, roommates }); }
}
