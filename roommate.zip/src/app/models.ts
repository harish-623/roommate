export type ExpenseCategory = 'Rent' | 'Groceries' | 'Electricity' | 'Cooking / Gas' | 'Maintenance' | 'Internet' | 'Other';
export interface Roommate { id: string; name: string; email: string; }
export interface Expense { id: string; date: string; month: string; category: ExpenseCategory; description: string; amount: number; paidBy: string; createdAt: string; }
export interface Payment { id: string; month: string; roommateId: string; amount: number; paid: boolean; paidAt?: string; }
export interface WorkbookData { roommates: Roommate[]; expenses: Expense[]; payments: Payment[]; revision: number; updatedAt: string; }
export const CATEGORIES: ExpenseCategory[] = ['Rent','Groceries','Electricity','Cooking / Gas','Maintenance','Internet','Other'];
