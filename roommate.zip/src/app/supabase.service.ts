import { Injectable } from '@angular/core';
import { createClient, SupabaseClient, User } from '@supabase/supabase-js';
import { environment } from '../environments/environment';
@Injectable({ providedIn: 'root' })
export class SupabaseService {
  readonly isConfigured: boolean;
  readonly client: SupabaseClient | null;

  constructor() {
    const url = environment.supabaseUrl.trim();
    const anonKey = environment.supabaseAnonKey.trim();
    this.isConfigured = Boolean(url && anonKey) && !/YOUR_PROJECT|YOUR_SUPABASE/i.test(`${url} ${anonKey}`);
    this.client = this.isConfigured
      ? createClient(url, anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
      : null;
  }

  async signIn(email: string, password: string) {
    if (!this.client) throw new Error('Configure your Supabase project URL and anon key in src/environments/environment.ts.');
    return this.client.auth.signInWithPassword({ email, password });
  }

  async signUp(email: string, password: string) {
    if (!this.client) throw new Error('Configure your Supabase project URL and anon key in src/environments/environment.ts.');
    return this.client.auth.signUp({ email, password });
  }

  async signOut() {
    if (!this.client) return;
    return this.client.auth.signOut();
  }

  async user(): Promise<User | null> {
    if (!this.client) return null;
    const { data } = await this.client.auth.getUser();
    return data.user;
  }

  async token(): Promise<string | null> {
    if (!this.client) return null;
    const { data } = await this.client.auth.getSession();
    return data.session?.access_token ?? null;
  }
}
