# RoomMate — Angular shared household expense tracker

Angular 20 standalone application for four roommates. Expenses are split equally (amount / 4). Supabase is used for authentication only; the shared household record is an Excel `.xlsx` workbook stored in **private Vercel Blob storage**.

## Features
- Separate `/login` and `/register` pages, with the authenticated expense dashboard at `/home` (Supabase Auth)
- Shared dashboard, category breakdown, equal per-person share
- Rent, groceries, electricity, cooking/gas, maintenance, internet and other expenses
- Monthly payment status for each of four roommates
- Yearly history and month-by-month totals
- Excel import and export with `Roommates`, `Expenses`, `Payments`, and `Yearly Summary` worksheets
- Private workbook storage behind authenticated Vercel API

## 1. Requirements
- Node.js 20.19+ (or a current Node 22 LTS release)
- npm
- Supabase project
- Vercel account with Blob storage enabled

## 2. Configure Supabase Auth
1. Create a project at https://supabase.com.
2. Open **Project Settings → API** and copy the Project URL and anon/public key.
3. In **Authentication → Providers → Email**, enable email/password sign-in.
4. For quick household setup, turn off email confirmation while testing, or keep it on and confirm each roommate's email.
5. Add your Vercel deployment URL to **Authentication → URL Configuration → Site URL / Redirect URLs**.
6. Put the URL and anon key in `src/environments/environment.ts` (the values there are browser-public keys; never put a service-role key in Angular).

Each of the four people should register their own login. The first authenticated household member initializes the shared workbook with four placeholder roommates. Use the Roommates page to edit names and optional email labels.

## 3. Configure Vercel Blob
1. Import this repository into Vercel.
2. In the Vercel project, open **Storage → Blob → Create Store** and connect it to the project.
3. Add the generated `BLOB_READ_WRITE_TOKEN` to the project's Environment Variables.
4. Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` as Vercel Environment Variables too.
5. Use **private** Blob storage. The workbook contains household financial information and should not be publicly accessible.

## 4. Run locally
```bash
npm install
npm install -D @vercel/node
npm install @vercel/blob
npm run start
```

The Angular dev server does not execute `/api` functions by itself. For local full-stack testing, use Vercel CLI:
```bash
npx vercel dev
```
Add the three server environment variables in `.env.local` (copy `.env.example`) and set the same Supabase URL/anon key in `src/environments/environment.ts`.

## 5. Deploy to Vercel
1. Push this folder to a GitHub repository.
2. In Vercel choose **Add New → Project**, import the repository.
3. Framework preset: Angular (or Other if autodetection does not select Angular).
4. Build command: `npm run build`.
5. Output directory: `dist/roommate/browser`.
6. Add `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `BLOB_READ_WRITE_TOKEN` to Production, Preview and Development as appropriate.
7. Deploy. Add the final `https://your-project.vercel.app` URL to Supabase Auth's allowed redirect URLs.

## 6. Workbook structure
The private workbook `roommate/roommate-expenses.xlsx` is created on first load and maintained by the API. It contains:
- `Roommates`: four member IDs, display names and email labels
- `Expenses`: one row per expense, including month, category, amount and payer
- `Payments`: one row per member/month payment status
- `Meta`: workbook revision and last update timestamp

The **Export Excel** action downloads an additional workbook with the same operational sheets plus a `Yearly Summary` sheet.

## Important operational notes
- Excel is the primary record as requested. Vercel Blob stores the actual `.xlsx` file; it is not stored on the ephemeral Vercel function filesystem.
- The API checks a workbook revision to detect stale edits and returns HTTP 409 so users can refresh rather than silently overwrite a newer version. This is suitable for a small household MVP, but Blob does not provide a transactional multi-user database. Two writes arriving at exactly the same time can still race. For high-concurrency or audit-critical usage, use a transactional database as the source of truth and generate Excel reports from it.
- This starter shares one workbook among authenticated users of this Vercel deployment. Anyone who can register for this Supabase project can sign in. For a private household, disable public sign-ups after creating/inviting the four accounts, or add an invitation/allowlist flow before production use.
- Payment status is a manual confirmation toggle; it does not initiate or verify bank transfers.
- Equal split is calculated across four people for every expense. It does not currently support partial-month occupancy or category-specific exclusions.
- Keep `BLOB_READ_WRITE_TOKEN` only in Vercel server environment variables. Never expose it in Angular environment files.

## Suggested next hardening steps
1. Add an invite-only registration policy so only the four intended members can join.
2. Add workbook backups/version retention and an audit log.
3. Add an admin role for changing member names and deleting mistakes.
4. Add import/restore validation before allowing arbitrary workbook uploads.
